# Minecraft Modrinth & GitHub (by Boy132 & H1ghSyst3m, fork maintained by Martindob)

Easily download, update, and manage Minecraft mods and plugins directly from Modrinth within the server panel - and, optionally, plugins from a GitHub repository that ships pre-built jars (see [GitHub repository source](#github-repository-source)).

> Originally created by [Boy132](https://github.com/Boy132) & [H1ghSyst3m](https://github.com/H1ghSyst3m) as part of [pelican-dev/plugins](https://github.com/pelican-dev/plugins), licensed under GPLv3 (see [LICENSE](LICENSE)). Modified by Martindob since September 2026 (search/filter fixes, Czech translation, "Always Use Latest Version" setting, automatic daily updates, the GitHub repository source with offers of new plugins, and various fixes — see the commit history for full details).

## Setup

Add `modrinth_mods` and/or `modrinth_plugins` to the _features_ of your egg to enable the mod/plugins page.
Also make sure your egg has the `minecraft` _tag_ and a tag matching a Modrinth loader name. (e.g. `paper` or `neoforge`)

Subuser permissions (the same for the Modrinth pages and the GitHub Plugins page): seeing the page
needs *file.read*, installing *file.create*, updating (or installing another version over an
installed one) *file.create* and *file.delete*, uninstalling *file.delete*. A subuser with only
console access doesn't see the pages at all.

## Installing and updating this plugin

> **Important (Pelican v1.0.0-beta38): after clicking _Update_ for this plugin in *Admin → Plugins*,
> always check its status there.** Pelican beta38's plugin update replaces the files and then fails
> (`PluginService::updatePlugin()` crashes on `$plugin->refresh()`), which leaves the plugin
> **"Not installed"**: it isn't loaded, its database migration doesn't run and its scheduled tasks
> (automatic updates, hourly offer check) stop. Click **Install** (beta38) - or **Enable** on newer
> Pelican versions that leave it disabled - to bring it back. Your settings in `.env` are kept.
>
> This is a bug in Pelican, not something this plugin can work around: a plugin that is
> "Not installed" isn't loaded at all, so none of its code can run to repair itself. The
> plugin's migration is safe to run again (it skips an existing table), and the GitHub pages keep
> working without the table (hiding offers and notifications then stay off until it exists).

## Settings

- **Always Use Latest Version**: skip the Minecraft version compatibility check entirely when searching for and installing mods/plugins, always using the newest available version for the detected loader. Useful for updating mods/plugins ahead of upgrading a server to a newer Minecraft version.
- **Enable Automatic Updates**: once a day, automatically update every installed mod/plugin on every server to its latest compatible version, without needing to click update manually - and plugins installed from the GitHub repository source (see below). An automatic update only ever moves **forward and stays as stable**: a Modrinth release is only replaced by a newer release (never by a beta/alpha; a beta by a newer beta or release), never by an older version, and a mod/plugin whose installed version is no longer in the compatible list (e.g. the server was pinned to an older Minecraft version) is left alone - the page still offers it for a manual decision. "Compatible" means the server's own Minecraft version (`MINECRAFT_VERSION`/`MC_VERSION`, or the most recent releases when it is `latest`) and loader, unless *Always Use Latest Version* is on. A failed automatic update is logged (the same failure at most once a day); a successful one is not.
- **Automatic Update Time**: what time of day that runs, in your own account's time zone (captured when you save the settings page), not the panel's. Handy for scheduling it a few minutes ahead of a server's own restart schedule. Only `HH:MM` is accepted; an unusable value in `.env` falls back to midnight instead of breaking the panel's schedule.

### Modrinth installs

- A file is downloaded by the panel (streamed to a temporary file, at most 256 MB), checked
  against the size and sha512 from Modrinth, written to the server under a temporary name
  (`.modrinth-*.part`) and only then renamed into place. A file with the same name (an update that
  keeps the file name) is set aside first and only deleted once the new one is in place.
  Temporary files left behind by an interrupted install are removed at the next install into
  that folder once they are older than an hour.
- Only plain `.jar` file names are installed or deleted; a folder is never deleted, even if the
  metadata names one.
- The installed list is kept in `mods/.modrinth-metadata.json` / `plugins/.modrinth-metadata.json`.
  If it can't be read (node unreachable, file damaged or larger than 1 MB), **nothing is installed,
  updated or removed** until it can - writing it would replace every entry with a single one. To
  recover a damaged file, fix the JSON by hand, or delete it (the mods/plugins stay installed but
  are no longer listed as installed from Modrinth; install them again from the page to track them).
- **GitHub repository source**: see below.

## Features

- **Browse and Search**: Access Modrinth's extensive mod library with search and pagination
- **Smart Installation**: One-click install with automatic latest version selection
- **Status Tracking**: See which mods are installed directly in the Modrinth list
- **Update Detection**: Automatic detection of available updates with one-click upgrade
- **Easy Uninstall**: Remove mods/plugins with confirmation and automatic file cleanup
- **Metadata Management**: Tracks installed versions, filenames, and installation dates
- **Version Compatibility**: Automatic filtering by Minecraft version and mod loader
- **Seamless Installation**: Downloads to the correct server directory (mods/ or plugins/)
- **Automatic Updates**: Optionally update every installed mod/plugin on every server once a day, without manual interaction (servers that are suspended, installing, being transferred or restored are skipped; one failing server never stops the run for the others)
- **Verified Downloads**: The panel downloads every Modrinth file itself, only from `https://cdn.modrinth.com`, and checks it against the size and sha512 Modrinth publishes before it is written to the server
- **GitHub Repository Source**: Install and update your own pre-built plugins from a (private) GitHub repository, gated on green CI, individually or all pending updates at once; new plugins in the repository are offered (never installed automatically); copies of them uploaded by hand are replaced with the repository version
- **Multilingual**: Supports English, German and Czech translations

## GitHub repository source

Besides Modrinth, plugins can come from a GitHub repository that contains **pre-built jars** and an
**index file** listing them - typically your own plugins, built and committed by your own CI. Paper
and Velocity servers get a **GitHub Plugins** page next to the Modrinth pages, where they can be
installed, updated and removed, and the daily automatic update keeps installed ones up to date.

### Index file

A JSON file in the repository (default `minecraft/releases.json`), for example:

```json
{
  "schema": 1,
  "plugins": [
    {
      "id": "myplugin",
      "name": "MyPlugin",
      "platform": "paper",
      "version": "1.4.0",
      "path": "minecraft/MyPlugin/paper/releases/MyPlugin-1.4.0.jar",
      "sha256": "<64 hex characters>",
      "size": 123456,
      "frozen": false,
      "previous_ids": ["myplugin-paper"]
    },
    {
      "id": "myplugin",
      "name": "MyPlugin",
      "platform": "velocity",
      "version": "1.2.0",
      "path": "minecraft/MyPlugin/velocity/releases/MyPlugin-1.2.0.jar",
      "sha256": "<64 hex characters>",
      "size": 23456,
      "frozen": false
    }
  ]
}
```

- `id` - stable identifier, used to recognise an installed plugin across versions. It only has
  to be unique **per platform** (since 1.6.0): a server only ever sees the entries of its own
  platform, so the Paper and the Velocity part of a plugin can share one id (`myplugin`). The
  same id twice on one platform: the second entry is skipped (and logged).
- `name` - the plugin's name (as in its `plugin.yml` / Velocity `@Plugin`).
- `platform` - `paper` or `velocity`.
- `version` - `x.y.z`; an update is only offered/applied for a *higher* version.
- `path` - the jar inside the repository (a relative path ending in `.jar`); the file name in
  `plugins/` is the last part of it.
- `sha256` and `size` - of the jar; the download is checked against both before anything is written.
- `frozen` - shown as information only.
- `previous_ids` (optional, since 1.6.0) - earlier ids of this plugin **on the same platform**,
  for when its id changes (see [Changing an id](#changing-an-id-previous_ids)). Up to 16 ids in
  the same format as `id`, not the entry's own id. An earlier id that is the current id of another
  entry of the same platform, or that several entries of the same platform list, is ignored
  (logged); the entry itself stays.

An index without `previous_ids` (as before 1.6.0) works exactly as before.
An index with an unknown `schema`, or that isn't valid JSON, installs nothing (and is logged).
Individual invalid entries are skipped and logged.

### Setup

1. Create a **fine-grained personal access token** on GitHub (*Settings → Developer settings →
   Personal access tokens → Fine-grained tokens*):
   - *Repository access*: **Only select repositories** → just the one repository.
   - *Repository permissions*: **Contents: Read-only** and **Actions: Read-only** (Metadata:
     Read-only is added automatically). Nothing else - no write permission of any kind.
   - Not a classic token (`ghp_...`): it reaches every repository of its owner, with `repo` even
     with write access. *Test connection* warns when the saved token is a classic one.
   - Pick an expiry you'll remember to renew; an expired token shows up as "GitHub rejected the
     token" on the page and in the log.
   A public repository works without a token (with GitHub's much lower anonymous rate limit).
2. In the panel: *Admin → Plugins → Minecraft Modrinth & GitHub → Settings → GitHub repository source*:
   enable it, enter the repository (`owner/repository`), the branch (default `main`) and the index
   path (default `minecraft/releases.json`), paste the token and save. Then use **Test connection**.
   - **Require green CI** (on by default): installing and updating is only possible from a commit
     whose GitHub Actions runs all finished successfully.
   - **Required workflow** (optional, empty by default): the file name of a workflow (e.g.
     `build.yml`) that must have a successful run on exactly that commit (push or manual run on the
     branch, or the pull request CI of that commit) for CI to count as green. Without it, a quick workflow (e.g. a linter) that finishes before the
     build has even started could make CI green too early. **For Ethoria set `build.yml`.**
     **Automatic updates need it (since 1.9.0)**: without a required workflow they install nothing
     (logged; *Test connection* warns).
   - **Quarantine of automatic updates** (hours, default 2, 0 = off, at most 168,
     `MINECRAFT_MODRINTH_GITHUB_QUARANTINE_HOURS`): see [Automatic updates: which commit](#automatic-updates-which-commit).
   - **Allowed commit authors** (GitHub logins or commit e-mail addresses separated by commas,
     `MINECRAFT_MODRINTH_GITHUB_ALLOWED_AUTHORS`, default
     `Martindob,arzinnn,zTeeCY,claude,noreply@anthropic.com` - the Ethoria contributors and
     Claude): see the same section. Empty: no check.
   - **Replace manual copies** (on by default, `MINECRAFT_MODRINTH_GITHUB_REPLACE_MANUAL`): a
     jar of a repository plugin that was put into `plugins/` by hand is replaced with the
     repository version (see [Manual copies](#manual-copies-replaced-with-the-github-version)).
     Off: such a plugin is only shown as **Installed manually**, as in 1.4.1.
   - Automatic updates use the existing **Enable Automatic Updates** setting and time.
3. The servers need the same egg setup as the Modrinth plugins page (`modrinth_plugins` or
   `plugins` feature, `minecraft` tag) plus a loader tag: `paper` (or `purpur`, `pufferfish`,
   `leaf`) for the `paper` platform, `velocity` for the `velocity` platform. Each server only sees
   the plugins of its own platform.

### How it works

- The panel reads the head commit of the branch, the GitHub Actions runs of exactly that commit
  (`head_sha` checked) and the index file at exactly that commit. A run counts when it is a push or
  a manual run (`workflow_dispatch`) on that branch (`head_branch` checked), or the pull request CI
  of that very commit: a pull request merged by fast-forwarding the branch to its tested head keeps
  the same SHA, so its pull request run is the commit's CI and the repository doesn't need to run
  CI a second time (a branch can only be fast-forwarded to a head that already contains it, so the
  pull request run tested exactly this tree). Of several runs of one workflow only the newest
  counts (a re-run, or a run that replaced a cancelled one). CI counts as **green** only when every run has finished as
  success/skipped/neutral and at least one succeeded (and, with a *Required workflow*, that one
  succeeded); any failed run makes it **red**, running ones **pending**, and a commit without runs
  stays **not verified** (not installable while green CI is required). Results are cached briefly
  (head commit 5 minutes, CI 1-10 minutes); the page's refresh button checks again - at most once
  per 30 seconds per server and 10 times a minute for the whole panel, so the token's rate limit
  can't be used up by clicking. Installing asks GitHub again under the same limit, otherwise it
  uses the cached state (the CI rule still applies to exactly the commit that is installed).
- **The panel downloads the jar itself** (GitHub contents API, at exactly the commit's SHA - never
  by branch name) and checks it three ways before anything is written (since 1.9.0; before only
  the first): (1) sha256 and size from the index of that commit, (2) size and **git blob SHA** of
  the file in that commit's tree (`git/trees/<commit>?recursive=1` - one request per commit for all
  its jars, a second, independent answer from GitHub; a tree GitHub truncates falls back to
  listing the jar's directory), (3) the plugin **name and version declared inside the jar**
  (`plugin.yml` / `paper-plugin.yml` / `velocity-plugin.json`) are the ones of the index entry, so
  an index can't pass off another plugin or an old jar as a new version. Any mismatch: nothing is
  installed, the old jar stays. Only then it is written to the server through the Wings file API.
  Wings never gets a GitHub URL or the token.
- **Never a downgrade** (since 1.9.0): installing over an installed plugin (*Update*, *Update all*,
  the automatic update) needs a **higher** version than the installed one - an index that points
  back to an older (perhaps vulnerable) version, or another jar with the same version, is refused.
  Going back stays a deliberate admin decision: remove the plugin, then install the repository's
  version.
- The jar is written under a temporary name and renamed into `plugins/`; an existing file is never
  overwritten in place (if the indexed name is already taken by the plugin's own current jar, a
  name with a hash suffix is used). On update the new jar is written first, then the metadata
  (which records the old jar as *to be deleted*), then the old jar is deleted. If the new jar or
  the metadata can't be written, the new jar is removed again and nothing changes. If only the
  **old jar can't be deleted**, the update stays (the new version is recorded) and the old jar
  stays listed as `pending_delete` in the metadata: it is deleted at the next installation, the
  hourly check or the automatic update, and the page shows a warning. Until then `plugins/` has
  two jars of the plugin - delete the old one by hand before restarting. A jar is never left
  untracked. A pending jar is only deleted if a regular file with the recorded name and size is
  still there. If another jar that looks like the same plugin is already there (another version
  of the same file, or a jar named after the plugin, e.g. a manual install), it is replaced
  while *Replace manual copies* is on and it passes the checks under
  [Manual copies](#manual-copies-replaced-with-the-github-version); otherwise installing is
  refused until you remove it.
- A full disk on the server is reported as such ("not enough disk space"), not as a conflict.
- Temporary uploads (`.github-*.part`) left behind by an interrupted install are removed by the
  hourly check once they are older than an hour.
- **Plugin configuration is never changed**: only the jar in `plugins/` and the metadata file
  `plugins/.github-plugins.json` (id, name, version, sha256, file name, repository, commit,
  install/update time, and `pending_delete` while an old jar waits for deletion) are written.
  Removing a plugin deletes its jar and metadata entry and keeps its folder
  (`plugins/<Plugin>/config.yml`, data, ...).
- **Damaged `plugins/.github-plugins.json`**: if it can't be read or isn't valid (or is larger than
  1 MB), the page says so and nothing is installed, updated or removed on that server - an empty
  list written over it would make every recorded jar untracked. To recover, fix the JSON by hand
  (the format is shown above), or delete the file and then delete the jars it listed from
  `plugins/` and install them again from the page (their configuration folders stay).
- The running server keeps using what it loaded: **a new or updated plugin is used after the next
  server restart**.
- **Update all**: shown on the GitHub Plugins page whenever at least one installed plugin has an
  update available (or a manual copy will be replaced), labelled with the count. Updates every one
  of them (and replaces those manual copies), each independently through
  the same install/update logic a single plugin's own **Update** button uses - one plugin failing
  (a checksum mismatch, a file conflict, GitHub being briefly unreachable, ...) never stops the
  rest. Ends in a single summary notification ("Updated 5 plugins", or "Updated 4 of 6 plugins"
  with what failed and why) instead of one per plugin. Subject to the same green-CI gate and rate
  limit as a single update - and the same permissions (see below).
- **Automatic updates** (daily, at the configured time) only update plugins that are already
  installed, only to a higher version, and only from a commit with green CI of the *Required
  workflow* - regardless of the "Require green CI" setting; which commit that is, see
  [Automatic updates: which commit](#automatic-updates-which-commit) - and, with *Replace manual copies* on, replace manual copies of
  repository plugins (not of plugins hidden on that server). Nothing new is ever installed
  automatically. Servers in a conflict
  state (suspended, installing, being transferred or restored, node in maintenance) and servers
  their node doesn't know are skipped; an error on one server never stops the run for the others.
- Page access requires the subuser permission *file.read*; installing requires *file.create*,
  updating *file.create* and *file.delete*, removing *file.delete*; hiding an offer ("Doesn't
  belong on this server") and "Offer again" require *file.create*; replacing a manual copy
  ("Replace with GitHub version") *file.create* and *file.delete*.

### Automatic updates: which commit

Since 1.9.0 the daily automatic update does not simply take the newest commit of the branch. It
takes the **newest commit** (walking back from the head, at most 30 commits, CI of at most 5 of
them asked) that

1. is **older than the quarantine** (default 2 h): the latest of the commit's date, the time this
   panel first saw it as the head and the time GitHub created its successful *Required workflow*
   run must lie that far back. A commit date can be set by whoever commits; the run's creation time
   is set by GitHub, so a back-dated commit doesn't get through earlier;
2. has **green CI on exactly that SHA**, with a successful run of the *Required workflow* (GitHub
   Actions runs of this repository only - commit statuses and check runs of other apps never
   count; another workflow that merely calls itself "Build" isn't `build.yml`);
3. passes the **author allowlist** (when set) for **every commit since the last automatically
   deployed one**: the author must be allowed - by its GitHub login when GitHub links the commit's
   e-mail to an account, otherwise by the author e-mail (Claude's commits,
   `Claude <noreply@anthropic.com>`, count as `claude` or by that e-mail); the committer must be
   allowed the same way or be GitHub itself (`web-flow` / `GitHub <noreply@github.com>` for
   rebase merges, `github-actions[bot]`) - GitHub as committer only counts because the author is
   allowed. **Author and committer are git metadata that whoever commits can write**: the
   allowlist is an extra tripwire against commits of anybody else; the real protection is who may
   push to the branch (collaborators, 2FA, ruleset) and the official CI on exactly the SHA.

A commit pushed shortly before the nightly run (or a red one) therefore doesn't stop the run: the
newest older commit that qualifies is used, its index and jars are read **at exactly that SHA**,
and the newer commits are taken by a later run once they qualify. Plugins are still only ever
updated to a higher version than installed. The panel log names the commit used, its author and
how many newer commits were held back
(`minecraft-modrinth: GitHub: automatic update uses commit <sha> (author <login>, build.yml green); 2 newer commit(s) up to head <sha> held back ...`),
and every installed jar gets a log line and an entry in the server's **activity log** with
repository, commit, author and sha256.

If the chosen commit does not descend from the last automatically deployed one (the branch was
force-pushed), nothing is updated automatically and an error is logged until an admin has checked
the repository. If no commit qualifies, nothing is updated (one log line). GitHub unreachable:
nothing is updated (fail closed).

**GitHub API budget.** Several servers, the hourly check and the page share one token (5 000
requests an hour for a token). What one run costs:

| What | Requests |
|---|---|
| hourly offer check | head commit 1, its CI 1 (cached 1-10 min), index 1 (cached 1 h per commit) |
| page view | the same, cached (refresh at most every 30 s per server, 10 a minute in total) |
| daily automatic update | head 1, commit history **1** (30 commits), CI of at most **5** candidates, a comparison with the last deployed commit only when it isn't among those 30 (1), the index 1, the commit's tree **1** (`git/trees/<sha>?recursive=1` - every jar's blob SHA at once) and one download per **distinct** jar that is updated (shared by all servers of the run) |

The chosen commit is shared by all servers of a run and cached for 10 minutes; commit contents
(index, tree) for an hour. When GitHub answers that fewer than 50 requests are left
(`X-RateLimit-Remaining`), or with 403/429 and `Retry-After`, the panel stops asking GitHub until
the reset: the automatic update stops for the rest of the run with **one** log line and every
server keeps its current jars (fail closed).

**Installing or updating by hand** is not delayed: it uses the newest commit (with green CI when
*Require green CI* is on). While that commit is younger than the quarantine, the GitHub Plugins
page shows a warning.

### Changing an id (previous_ids)

A server records its installed plugins (and the plugins hidden or announced on it) by `id`. A new
`id` alone would make the plugin a **new** plugin: offered again, while the installed one would show
as *No longer in repository* and never be updated. To change an id, the entry keeps the old one
in `previous_ids`:

```json
{ "id": "myplugin", "platform": "velocity", "previous_ids": ["myplugin-velocity"], ... }
```

- A plugin installed under an id from `previous_ids` **is** that plugin: the page shows its
  normal state (*Up to date*, *Update available*, ...), *Update*, *Update all*, the daily
  automatic update and the hourly offer check treat it as installed - nothing has to be reinstalled
  by hand. Hiding ("Doesn't belong on this server") and announcements stored under the old id count
  for the new id too (a plugin hidden under the old id stays hidden, one announced under the old id
  is not announced again; *Offer again* clears both).
- **Converted to the new id**: the next time the panel writes `plugins/.github-plugins.json` for
  the plugin (*Install*/*Update* of any plugin, the daily automatic update), and at the hourly offer
  check, entries recorded under an earlier id get the current id (only the `id` changes - version,
  file, install date stay) and the stored hidden/announced offers move to it (merged if both
  exist). This only happens from a commit with **green CI**, and only on servers whose platform has
  an entry with `previous_ids` at all; on such a server the hourly check writes the metadata file
  once (a line in the panel log: `... now records <old> as <new>`). Once every server has been
  converted, the old id can be removed from `previous_ids`.
- Only within one platform, and never an entry recorded for the other platform (e.g. after the egg
  of a server was changed): ids are unique per platform only.
- **Safety net**: installing a plugin while the same plugin (same `name`) is already recorded on the
  server under an id the index doesn't list in `previous_ids` is refused ("already installed as
  ...") instead of putting a second jar of it into `plugins/`.
- **Order when switching an index to new ids**: update this plugin in the panel to 1.6.0 **first**,
  then publish the index. Versions before 1.6.0 skip the second entry of an id that is used on both
  platforms and know nothing about `previous_ids` - with them, installed plugins would show as
  removed and the new ids as new plugins.

### New plugins

When the repository gets a plugin that a server doesn't have yet, the panel **offers** it - it is
never installed automatically.

- **What counts as new**: a plugin in the index for the server's platform (`paper` plugins only on
  Paper/Purpur/... servers, `velocity` plugins only on Velocity servers) that is not installed from
  the repository on that server and that nobody has hidden for that server. A server whose
  platform can't be determined (no loader tag, no plugins feature) is offered nothing. A plugin
  whose jar is already in `plugins/` without being installed from here (a manual install, a
  Modrinth copy - recognised like the conflict check above) is not offered as new: it shows as
  **Manual copy - will be replaced** (counted as an update, see
  [Manual copies](#manual-copies-replaced-with-the-github-version)) or, when it can't be
  replaced automatically (or the setting is off), as **Installed manually**.
- **GitHub Plugins page**: new plugins are listed first with the label **New - offered for
  installation** (then available updates), with a note above the table. Next to **Install** there
  is **Doesn't belong on this server**, which hides the offer on that server only. Hidden plugins
  can be shown with **Show hidden (n)** and brought back with **Offer again**.
- **Menu badge**: the *GitHub Plugins* menu item shows how many plugins are offered (new plus
  updates; a manual copy that will be replaced counts as an update) - orange when there are updates, blue when there are only new plugins; the tooltip
  splits the number. The badge only reads a cached count (written by the hourly check below and by
  every visit of the page), so drawing the menu never contacts GitHub or the server's node; while
  there is no count (e.g. right after the plugin update, until the first check) there is no badge.
- **Notifications**: an hourly check (`p:minecraft-modrinth:github-offers`, runs only while the
  GitHub source is enabled) reads the repository state once for all servers, then the metadata
  file and the jar list of `plugins/` of every Paper/Velocity server (two Wings requests per server,
  a third one - Modrinth's metadata file - only when a manual copy of a repository plugin is there;
  servers in a conflict state - suspended, installing, being transferred or restored - and servers
  their node doesn't know are skipped). For every new plugin a server hasn't been
  told about yet, the panel sends a notification (the bell in the panel): *"On server {server},
  the new plugin {name} {version} from the repository is available for installation"*, with a
  button to the GitHub Plugins page. Each plugin is announced **once per server** - not again for
  a newer version, after a hide/offer again, or after it was removed; more than three new plugins
  at once are announced in one notification. With *Require green CI* on, nothing is announced
  while CI of the newest commit isn't green (the next check after it turns green does it).
- **Delivery**: the notifications are written to the panel database directly, not through the
  queue, so they arrive even without a running queue worker.
- **Who is notified**: the server owner and every subuser with *file.create* on that server (the
  people who can install it). Panel admins are not notified for every server they can see - they
  see the badge when they open a server.
- **Where it is stored**: hidden offers and which plugins were announced are kept per server in
  the panel database (table `minecraft_modrinth_github_offers`, created by the plugin's migration
  when the plugin is installed or updated, deleted together with the server). The server's
  `plugins/.github-plugins.json` stays exactly as in 1.2.0. If the table is missing (migration not
  run), offers are still shown and counted, but hiding is not possible and nothing is announced.

### Manual copies (replaced with the GitHub version)

A jar of a repository plugin that was put into `plugins/` by hand (SFTP, file manager, an older
manual install) is **replaced with the repository version** while *Replace manual copies* is on
(the default) - no need to delete it first. Off, the plugin is only shown as **Installed
manually**, as in 1.4.1.

- **Where**: the GitHub Plugins page shows such a plugin as **Manual copy - will be replaced**
  (installed column: the version from the file name, marked "manual"; the tooltip names the
  file), with a note above the table and the button **Replace with GitHub version** (needs
  *file.create* and *file.delete*). **Update all** includes it, and the **daily automatic
  update** (with *Enable Automatic Updates* on) replaces it on every server. The hourly check
  counts it as an update in the menu badge. *Update* of an installed plugin also replaces a manual
  copy that lies next to it. A plain *Install* of a new plugin never deletes anything.
- **Keeping a manual copy**: **Doesn't belong on this server** hides the plugin on that server -
  a hidden plugin is never replaced (it shows as *Installed manually* with *Offer again*).
- **How it is replaced** (the same safe order as an update): the panel downloads and verifies the
  repository jar, checks the manual copy (below), writes the new jar (temporary name, then
  rename), saves the metadata with the new entry **and** the manual copy as `pending_delete`
  (with `replaced_by`), and only then deletes the manual copy. If the new jar or the metadata
  can't be written, the new jar is removed again and the manual copy stays. If only the manual
  copy can't be deleted, it stays recorded as pending and is deleted at the next installation,
  the hourly check or the automatic update (the page warns until then). Two jars of the plugin
  are never left behind untracked, and a manual copy is never deleted before the new jar is
  written and recorded. If the manual copy has exactly the indexed file name, the new jar gets a
  name with a hash suffix (an existing file is never overwritten).
- **What counts as a manual copy** (conservative - a foreign plugin must never be deleted):
  - recognised by file name only against the index entries **for the server's platform**:
    another version of the indexed file name (`EthoriaChat-1.8.0.jar`) or a jar named after the
    plugin (`EthoriaChat.jar`, `EthoriaChat-1.8.jar`);
  - only plain jar files directly in `plugins/` - sub folders are never looked at, symlinks and
    folders named `*.jar` are never touched, nor are jars with unusual names;
  - never a jar that matches **more than one** index entry, never a jar the **Modrinth page
    manages** (listed in `plugins/.modrinth-metadata.json`; nothing is replaced while that file
    can't be read), and not more than 3 copies of one plugin at once;
  - never a copy whose file name carries a **newer version** than the repository's
    (`EthoriaChat-1.9.0.jar` while the index has 1.8.1, e.g. a hotfix uploaded by hand): it is
    never replaced with the older repository jar, automatically or by a click;
  - **checked by the plugin name inside**: before deleting it, the panel reads the manual copy
    from the node and compares the `name` of its `plugin.yml` / `paper-plugin.yml` (Paper) or the
    `id` of its `velocity-plugin.json` (Velocity) with the repository jar. Wings can't read a
    single file inside a jar, so the **whole jar is downloaded** to the panel for that - but only
    when it is about to be replaced (not for page views or the hourly check), at most 50 MB, and
    the result is remembered for a day per file name, size and modification time. A copy that
    declares another plugin, has no descriptor, isn't a jar or is larger than 50 MB is **kept**,
    the replacement is refused with an explanation and the copy is no longer offered for
    replacement (for a day, or until the file changes). If the node can't be read right now,
    nothing happens and it is tried again later.
- **Logged**: every deleted manual copy is written to the server's **activity log** ("Deleted
  /plugins/<file>", with `replaced_by`, by the user who clicked or by the system for the automatic
  update) and as one line to the panel log (`minecraft-modrinth: GitHub: deleted the manual copy
  plugins/<file> on server #<id>, replaced with <plugin> <version> from the repository`). A
  refused replacement is logged as an error (the same one at most once per hour).
- The plugin's configuration folder (`plugins/<Plugin>/`) is never touched; the new version is
  used after the next server restart.

### Security

- The token is stored **encrypted** with the panel's `APP_KEY` (`Crypt::encryptString`); `.env`
  only ever contains the ciphertext (`MINECRAFT_MODRINTH_GITHUB_TOKEN_ENCRYPTED`). The settings
  form never shows it (leave the field empty to keep it, or use *Delete the saved token*). If
  `APP_KEY` changes, save the token again.
- The token is only sent to `https://api.github.com`, always with TLS certificate verification.
  Redirects to GitHub's content hosts (exactly `raw.githubusercontent.com`,
  `objects.githubusercontent.com`, `codeload.github.com` - since 1.9.0 no other
  `*.githubusercontent.com` host) are followed without it, https only; redirects anywhere else
  are refused. JSON answers are limited to 8 MB.
- The token is never logged: failures are reported as short messages without request details, at
  most once per hour per problem.
- Everything from the repository is validated: repository/branch/index path in the settings, the
  index (paths must be relative, without `.`/`..`, ending in `.jar`; versions `x.y.z`; sha256 64 hex
  characters), and every jar's sha256 and size. Requests to GitHub time out after 3 s (connect) /
  15 s (120 s for a jar download); jars are limited to **50 MB** (index entries with a larger
  `size` are skipped): the panel holds a jar in PHP memory while it checks and writes it.
- Names, versions and server names in notifications are escaped (Filament renders notification
  text as HTML).
- A fine-grained token limited to one repository with read-only Contents/Actions can't change
  anything on GitHub.
- What protects what (1.9.0): a changed download (network, content host) can't match the index
  sha256 **and** the commit's git blob SHA; an index entry can't install another plugin or an old
  jar under a new version (descriptor check) nor an older version over a newer one (no downgrade);
  a fake "green" from another app or workflow doesn't count (GitHub Actions runs of the required
  workflow on exactly the SHA); a bad commit on the branch has the quarantine to be noticed before
  the automatic update takes it; a rewritten branch stops automatic updates. What it can't protect
  against: somebody who may push to the branch and gets a malicious but green commit through the
  repository's own CI - that is up to the repository (ruleset, reviews, 2FA, CI that checks that
  the jars match the source).

### Limitations

- A manually installed jar is recognised only by its file name (another version of the indexed
  file name, or a jar named after the plugin). A manual copy with an unrelated file name is not
  recognised (finding it would mean downloading every jar in `plugins/` from the node); the
  `name` inside a recognised copy is only read right before it is replaced.
- The panel keeps a jar in memory while installing it, hence the 50 MB limit.

## Changes

- **1.9.1** - Automatic updates without a *Required workflow* (since 1.9.0 they install nothing then)
  log **one warning line** instead of an error with a stack trace (at most once per
  `report_throttle_minutes`). Set *Required workflow* (e.g. `build.yml`) in the plugin settings
  to turn the GitHub source's automatic updates on. Nothing else changes.
- **1.9.0** - Supply chain hardening of the GitHub source. **Automatic updates** take the newest
  commit that is older than the new **quarantine** (default 2 h, 0 = off; counted from the latest
  of commit date, first sighting by the panel and GitHub's CI run), has green CI of the *Required
  workflow* on exactly that SHA and passes the **author allowlist** (default: the Ethoria
  contributors and Claude, by login or - without a GitHub account - by e-mail) for every commit
  since the last automatic deploy - walking back from a head that is too young instead of skipping
  the night (one request for 30 commits, CI of at most 5, one tree request per commit, decision
  shared by all servers; under 50 remaining API requests or on a rate limit it stops with one log
  line and keeps the jars); they need a *Required workflow* (without one they install nothing) and stop when the
  branch was force-pushed. Every downloaded jar is checked against the index sha256/size, the
  **git blob SHA of the file in that commit's tree** (one tree request per commit) and the **plugin name and version inside the
  jar**. **Never a downgrade**: an older (or same-version, other) jar is never installed over an
  installed plugin. CI counts only GitHub Actions runs of exactly the configured repository.
  Redirects only to exactly `raw.githubusercontent.com`, `objects.githubusercontent.com`,
  `codeload.github.com`; TLS verification stated explicitly; JSON answers limited to 8 MB.
  Every install is logged with commit, author and sha256 (panel log and the server's activity
  log). *Test connection* warns about a classic token and a missing required workflow; the page
  warns while the newest commit is in the quarantine. The index format is unchanged (`sha256`
  and `size` were already required). Update the settings after updating: check *Required workflow*
  (`build.yml` for Ethoria), the quarantine and the author allowlist (prefilled with the Ethoria
  contributors and Claude).

- **1.8.0** - CI of a pull request merged by fast-forward counts: besides a push, a manual run
  (`workflow_dispatch`) on the branch and the pull request CI of exactly the same commit make it
  green, so a repository that merges pull requests by fast-forwarding the branch to the tested
  commit doesn't need a second CI run (half the GitHub Actions minutes). Only the newest run of
  each workflow counts (a cancelled or failed run replaced by a newer one no longer turns CI red).
- **1.7.2** - Refusals the GitHub Plugins page explains on its own (the newest commit's CI isn't
  green yet, or the page was out of date) are no longer written to the panel's error log with a
  stack trace. *Update all* stops at the first "CI not green" - typically a commit pushed after the
  page was opened - with one message, instead of failing every plugin with the same error.
- **1.7.1** - Safer automatic updates. Modrinth: the daily update only installs a newer version
  that is at least as stable as the installed one - a release is no longer replaced by a newer
  beta/alpha, and a mod/plugin is no longer "updated" to an older version when the installed one
  isn't in the server's compatible list (e.g. after pinning the server to an older Minecraft
  version); such a mod/plugin is left alone and still offered on the page. The server's Minecraft
  version is read like the egg reads it (the egg's default when the server has no value of its
  own; `latest` in any case and with spaces). GitHub: a manual copy whose file name carries a
  newer version than the repository's (a hotfix uploaded by hand) is never replaced with the
  older repository jar.
- **1.7.0** - The LuckPerms source (luckperms.net) is removed completely: no more LuckPerms page,
  no LuckPerms settings section, no LuckPerms step in the daily automatic update and no
  notifications about new LuckPerms builds; the Modrinth pages no longer check for a second
  LuckPerms jar. A LuckPerms jar already on a server is left alone (it is not deleted, and from
  now on it is just a plugin like any other - updated by hand, from Modrinth or not at all).
  The old settings `MINECRAFT_MODRINTH_LUCKPERMS_ENABLED` / `MINECRAFT_MODRINTH_LUCKPERMS_MODE`
  in the panel's `.env` are ignored and can be deleted; bell notifications sent earlier still
  link to the removed page. Temporary `.luckperms-*.part` files from an interrupted LuckPerms
  update are no longer cleaned up automatically (delete them by hand if there are any). The
  Modrinth and GitHub sources work as in 1.6.0.
- **1.6.0** - Plugin ids only have to be unique **per platform**: the Paper and the Velocity part of
  a plugin can share one id (an index with `myplugin` for both is no longer cut down to one of
  them), and every lookup by id (page, install/update, *Update all*, daily update, hourly check,
  manual copies) stays within the server's platform. New optional index field **`previous_ids`**
  for changing an id: a plugin installed under an earlier id is recognised as installed and keeps
  being updated (no manual reinstall), hidden/announced offers under the earlier id still count,
  and the server's `plugins/.github-plugins.json` and stored offers are converted to the new id
  (at the next write and the hourly check, from a commit with green CI). Installing a plugin that
  is already recorded under an unknown id with the same name is refused instead of leaving two
  jars. An index without `previous_ids` works as before. Update the panel plugin before
  publishing an index with changed ids.
- **1.5.0** - Manual copies are replaced with the GitHub version: a jar of a repository plugin
  that was uploaded to `plugins/` by hand no longer blocks it ("remove it first"). New setting
  *Replace manual copies* (on by default): the GitHub Plugins page shows it as "Manual copy - will
  be replaced" with **Replace with GitHub version**, "Update all" and the daily automatic update
  replace it, the badge counts it as an update; the new jar is written and recorded first, the
  manual copy is deleted only then (or later, if deleting fails) and logged in the server's
  activity log. Only a jar recognised by name for exactly one plugin of the server's platform,
  directly in `plugins/`, not managed by the Modrinth page, and declaring the same plugin name
  in its `plugin.yml` / `velocity-plugin.json` is replaced; plugins hidden on a server are left
  alone. Off: as in 1.4.1.
- **1.4.1** - Fix: saving the settings failed with "Enter the time as HH:MM" even for a valid time
  (e.g. 15:55). Filament's time picker keeps the picked value as "YYYY-MM-DD HH:mm:ss", which the
  check only accepted as "HH:MM"; the date part and seconds are now dropped and only HH:MM is stored.
- **1.4.0** - New **LuckPerms source (luckperms.net)**: a LuckPerms page on Paper/Spigot/Folia/Purpur
  (Bukkit build) and Velocity servers with the installed and newest version, the latest changes and
  Install / Update / Remove; an existing LuckPerms jar (uploaded by hand or from Modrinth) is
  recognised and taken over (its Modrinth entry is removed), never leaving two LuckPerms jars;
  daily automatic update at the existing update time, or only a notification in the bell (setting);
  downloads only from `download.luckperms.net`, without redirects, checked as a jar of exactly that
  platform and version (no checksum is published). The Modrinth pages no longer install a second
  LuckPerms next to an existing one.
- **1.3.1** - Security and reliability fixes from an audit: the Modrinth pages now check subuser
  permissions like the GitHub page (seeing *file.read*, installing *file.create*, updating also
  *file.delete*, uninstalling *file.delete*); Modrinth files are downloaded by the panel only from
  `cdn.modrinth.com` and checked against their sha512; unreadable or damaged metadata is never
  overwritten; only `.jar` files are ever deleted, never folders; an old jar that can't be deleted
  after a GitHub update is recorded and deleted later instead of leaving two untracked jars; a
  broken server no longer stops the daily update or the hourly check for everyone; metadata files
  are read with a 1 MB limit; full disks and unknown servers are recognised; names in
  notifications are escaped and the loader icon is static; new *Required workflow* setting;
  GitHub refreshes are rate limited; scheduled tasks can no longer block each other forever.
