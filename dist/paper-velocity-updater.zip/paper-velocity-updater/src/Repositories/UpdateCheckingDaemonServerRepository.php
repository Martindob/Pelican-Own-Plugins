<?php

namespace Martindob\PaperVelocityUpdater\Repositories;

use App\Repositories\Daemon\DaemonServerRepository;
use Exception;
use Illuminate\Http\Client\Response;
use Martindob\PaperVelocityUpdater\Services\PaperVelocityUpdateService;

/**
 * Decorates the panel's own DaemonServerRepository so that a "start"/"restart"
 * power action applies whatever update was already staged in the background
 * (see PaperVelocityUpdateService::checkForUpdates(), run on a schedule),
 * right before the signal is forwarded to Wings. This covers the client API
 * and a Schedule's "Power Action" task, both of which resolve this class out
 * of the container (checked directly against the panel's own PowerController
 * and TaskServiceProvider).
 *
 * Deliberately does NOT cover the Console page's own Start/Restart/Stop/Kill
 * buttons: those send the signal over the browser's own WebSocket connection
 * straight to Wings (server-console.blade.php's `socket.send({'event': 'set
 * state', ...})`), with no panel-side PHP code in that path at all - there is
 * nothing here to hook for that specific interaction.
 *
 * Doesn't cover the server list's power buttons either: ListServers builds
 * its own `new DaemonServerRepository()` instead of resolving it from the
 * container, so this decorator is never used there.
 */
class UpdateCheckingDaemonServerRepository extends DaemonServerRepository
{
    private const UPDATE_ON_SIGNALS = ['start', 'restart'];

    public function __construct(private readonly PaperVelocityUpdateService $updateService) {}

    /**
     * Applying a staged update is just a couple of fast rename calls (see
     * PaperVelocityUpdateService::applyPendingUpdate()), not a download, so
     * unlike the old design this never needs to abort or delay the actual
     * power action: any failure here is swallowed (and throttled-logged by
     * the service itself) and the signal is forwarded exactly as it would be
     * without this plugin. Worst case, the server starts on its current jar
     * and the swap is retried on the next restart.
     */
    public function power(string $action): Response
    {
        if (isset($this->server) && in_array($action, self::UPDATE_ON_SIGNALS, true)) {
            try {
                $this->updateService->applyPendingUpdate($this->server);
            } catch (Exception $exception) {
                report($exception);
            }
        }

        return parent::power($action);
    }
}
